from sqlite3.dbapi2 import connect
import discord, sqlite3, asyncio, random, os, keep_alive
from discord.ext import commands

token = os.environ['touki']
prefix = "a!"
client = commands.Bot(command_prefix=prefix)
client.remove_command('help')

async def GetMsg(
    client, ctx, contentOne="Default", timeout = 99
):
    await ctx.send(contentOne)
    try:
        msg = await client.wait_for(
            "message",
            timeout=timeout,
            check=lambda message: message.author == ctx.author
            and message.channel == ctx.channel
        )
        if msg:
            return msg.content
    except asyncio.TimeoutError:
        return False

@client.event
async def on_ready():
    print('\033[94m'+'BOT CONECTADO'+'\033[0;0m')
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name='Bot em Alpha'))

@client.command()
async def test(ctx):
    await ctx.send("Tested")
    
@client.command()
async def help(ctx):
    embed=discord.Embed(title="Comandos:")
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/874295858026397727/884492509508677702/tasker.jpg")
    embed.add_field(name="a!showlicao", value="Mostra lições adicionadas", inline=False)
    embed.add_field(name="a!addlicao", value="Comando para adicionar lições", inline=False)
    embed.add_field(name="a!delicao {descrição}", value="Exclui a lição com essa descrição", inline=False)
    embed.set_footer(text="Mais funções estão por vir ;)")
    await ctx.send(embed=embed)

###Adiciona lição a table
@client.command()
async def addlicao(ctx):
    materia = await GetMsg(client, ctx, contentOne = "Qual matéria?")
    descrição = await GetMsg(client, ctx, contentOne = "Descrição:")
    quando = await GetMsg(client, ctx, contentOne = "Pra quando? {dia|mês|ano}")

    if not materia:
        await ctx.send("Seu lerdo! n deu tempo.")
        return
    elif not descrição:
        await ctx.send("Seu lerdo! n deu tempo.")
        return
    elif not quando:
        await ctx.send("Seu lerdo! n deu tempo.")
        return

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"""INSERT INTO licao VALUES ('{materia}','{quando}','{descrição}')""")
    conn.commit()

    await ctx.send(f"Adicionado lição de {materia} pra {quando} sobre {descrição}")

#mostra todas as lições da table
@client.command()
async def showlicao(ctx):
    rowslen = 0
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM licao')
    rows = cursor.fetchall()

    for descrição in rows:
            rowslen = rowslen + 1
            
    embed = discord.Embed(title = "Tarefas pendentes", description = f"{rowslen} lições listadas.")
    embed.set_footer(text="a!help pra mais comandos")
    if not rows:
        await ctx.send("Não tem lição pra fazer! :D\n~~Ou ngm adiconou ainda :v~~")
    if rows:
        for materia, quando, descrição in rows:
            embed.add_field(
                name=f"Lição de {materia} para {quando}", value = descrição, inline=False)
        await ctx.send(embed=embed)

@client.command()
async def materia(ctx, args):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM licao WHERE materia = '{args}'")
    embed = discord.Embed(title = f"Tarefas pendentes de {args}")
    embed.set_footer(text="a!help pra mais comandos")
    rows = cursor.fetchall()
    for materia, quando, descrição in rows:
        embed.add_field(name=f"Lição de {materia} para {quando}", value = descrição, inline=False)
    await ctx.send(embed=embed)


@client.command()
async def delicao(ctx, *, args):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM licao WHERE descricao = '{args}'")
    rows = cursor.fetchall()
    if rows:
        cursor.execute(f"DELETE FROM licao WHERE descricao = '{args}'")
        conn.commit()
        await ctx.send('excluido')
    if not rows:
        await ctx.send(f'Nenhum lição com "**{args}**" encontrada')

keep_alive.keep_alive()
client.run(token)
